package com.example.linarrra

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.graphics.Color

// МИНИМАЛЬНОЕ ОПРЕДЕЛЕНИЕ ТЕМЫ, ЧТОБЫ ИЗБЕЖАТЬ ОШИБОК
@Composable
fun DocumentAppTheme(content: @Composable () -> Unit) {
    // Используем стандартные цвета Material Design 3
    val colors = lightColorScheme(
        primary = Color(0xFF00796B), // Темно-бирюзовый
        onPrimary = Color.White,
        primaryContainer = Color(0xFFB2DFDB),
        onPrimaryContainer = Color(0xFF00201D),
        secondary = Color(0xFF8BC34A), // Светло-зеленый
        onSecondary = Color.Black,
        background = Color.White,
        surface = Color.White
    )
    MaterialTheme(
        colorScheme = colors,
        typography = MaterialTheme.typography,
        content = content
    )
}

// Обертка для запуска приложения: НАЧАЛЬНАЯ ТОЧКА
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Устанавливаем контент Compose для всей активности
        setContent {
            // Оборачиваем наше приложение в определенную выше тему
            DocumentAppTheme {
                DocumentAppAuth() // Запускаем нашу основную Composable-функцию
            }
        }
    }
}


// --- ЭКРАН-КОНТЕЙНЕР ДЛЯ НАВИГАЦИИ ---
// Этот Composable управляет, какой экран (Вход или Регистрация) сейчас показывается.

enum class AuthScreen {
    LOGIN,
    REGISTRATION
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentAppAuth() {
    // Состояние, которое определяет текущий экран (по умолчанию - Вход)
    var currentScreen by remember { mutableStateOf(AuthScreen.LOGIN) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Электронный документооборот",
                        fontWeight = FontWeight.Bold
                    )
                },
                // ИСПОЛЬЗУЕМ ВСТРОЕННЫЙ МЕТОД ДЛЯ ЦВЕТОВ
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            when (currentScreen) {
                AuthScreen.LOGIN -> LoginScreen(
                    onNavigateToRegistration = {
                        currentScreen = AuthScreen.REGISTRATION
                    },
                    onLoginSuccess = {
                        // TODO: Здесь будет логика перехода к главному экрану
                        println("Успешный вход! Переходим на главный экран.")
                    }
                )
                AuthScreen.REGISTRATION -> RegistrationScreen(
                    onNavigateToLogin = {
                        currentScreen = AuthScreen.LOGIN
                    },
                    onRegistrationSuccess = {
                        // После успешной регистрации переходим на экран входа
                        currentScreen = AuthScreen.LOGIN
                    }
                )
            }
        }
    }
}

// --- ЭКРАН ВХОДА ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(onNavigateToRegistration: () -> Unit, onLoginSuccess: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Добро пожаловать!",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Поле для Email
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Электронная почта") },
                leadingIcon = { Icon(Icons.Filled.Email, contentDescription = "Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Поле для Пароля
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Пароль") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Пароль") },
                trailingIcon = {
                    val image = if (passwordVisible)
                        Icons.Filled.Visibility
                    else Icons.Filled.VisibilityOff

                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(imageVector = image, contentDescription = "Показать/скрыть пароль")
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Кнопка Входа
            Button(
                onClick = {
                    // TODO: Здесь будет логика проверки учетных данных
                    if (email.isNotEmpty() && password.isNotEmpty()) {
                        // В реальном приложении: onLoginSuccess()
                        println("Попытка входа с email: $email")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Войти", fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Ссылка на Регистрацию
            Text(
                text = "Нет аккаунта? Зарегистрироваться",
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clickable(onClick = onNavigateToRegistration)
                    .padding(8.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

// --- ЭКРАН РЕГИСТРАЦИИ ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrationScreen(onNavigateToLogin: () -> Unit, onRegistrationSuccess: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Регистрация",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Поле для Имени
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Имя пользователя") },
                leadingIcon = { Icon(Icons.Filled.Person, contentDescription = "Имя") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Поле для Email
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Электронная почта") },
                leadingIcon = { Icon(Icons.Filled.Email, contentDescription = "Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Поле для Пароля
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Пароль") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Пароль") },
                trailingIcon = {
                    val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(imageVector = image, contentDescription = "Показать/скрыть пароль")
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Поле для Подтверждения Пароля
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text("Подтвердить пароль") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Подтвердить пароль") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Кнопка Регистрации
            Button(
                onClick = {
                    // TODO: Здесь будет логика проверки и регистрации пользователя
                    if (password == confirmPassword && email.isNotEmpty()) {
                        // В реальном приложении: onRegistrationSuccess()
                        println("Попытка регистрации: $email")
                        onRegistrationSuccess()
                    } else if (password != confirmPassword) {
                        // В реальном приложении: показать ошибку пользователю
                        println("Пароли не совпадают")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Text("Зарегистрироваться", fontSize = 18.sp)
            }

            // Ссылка на Вход
            Text(
                text = "Уже есть аккаунт? Войти",
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier
                    .clickable(onClick = onNavigateToLogin)
                    .padding(8.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

// Пример превью, чтобы увидеть, как выглядит приложение
@Preview(showBackground = true)
@Composable
fun DocumentAppPreview() {
    // Используем определенную выше тему
    DocumentAppTheme {
        DocumentAppAuth()
    }
}
