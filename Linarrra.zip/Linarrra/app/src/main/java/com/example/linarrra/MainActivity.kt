package com.example.linarrra

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date
import android.util.Log

// Добавляем для Composable-функций с раскрывающимся списком
@OptIn(ExperimentalMaterial3Api::class)

// --- КОНСТАНТЫ ---
val DocumentTypes = listOf(
    "Договор",
    "Счет-фактура",
    "Акт приема-передачи",
    "Заявление"
)
// Email директора для хардкодной проверки роли
const val ADMIN_EMAIL = "admin@mail.ru"

// --- МОДЕЛИ ДАННЫХ ---
data class Document(
    val id: String = "",
    val userId: String = "",
    val userName: String = "", // Имя сотрудника, создавшего документ
    val title: String = "",
    val type: String = DocumentTypes.first(),
    val status: String = "Черновик",
    val createdAt: Long = System.currentTimeMillis(),
    val fields: List<Field> = emptyList()
)

data class Field(
    val id: String = "",
    val name: String = "",
    var value: String = "",
    val type: FieldType = FieldType.TEXT,
    val required: Boolean = false
)

enum class FieldType {
    TEXT, NUMBER, DATE, SIGNATURE
}

data class UserMetadata(
    val uid: String = "",
    val displayName: String = "",
    val email: String = ""
)

// --- VIEW MODEL ---
class DocumentViewModel : ViewModel() {
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    // Состояние аутентификации
    var isAuthenticated by mutableStateOf(false)
        private set
    var isLoading by mutableStateOf(true)
        private set
    var userDisplayName by mutableStateOf<String?>(null)
        private set
    var isAdmin by mutableStateOf(false)
        private set

    // Списки документов для сотрудника
    var documents = mutableStateListOf<Document>() // Активные (Черновик, На подпись)
        private set
    var archivedDocuments = mutableStateListOf<Document>() // Архив (Подписан, Отклонен)
        private set

    // Списки данных для директора
    var userMetadata = mutableStateListOf<UserMetadata>()
        private set
    var approvalQueue = mutableStateListOf<Document>()
        private set

    // Состояние выбранного документа для редактирования
    var currentDocument by mutableStateOf<Document?>(null)
        private set
    var currentDocumentFields = mutableStateListOf<Field>()
        private set

    init {
        auth.addAuthStateListener { firebaseAuth ->
            val user = firebaseAuth.currentUser
            isAuthenticated = user != null
            userDisplayName = user?.displayName

            isAdmin = user?.email == ADMIN_EMAIL

            if (isAuthenticated) {
                if (isAdmin) {
                    loadAllEmployees()
                    loadApprovalQueue()
                } else {
                    loadDocuments() // Загрузка активных
                    loadArchivedDocuments() // Загрузка архивных
                }
            } else {
                documents.clear()
                archivedDocuments.clear()
                userMetadata.clear()
                approvalQueue.clear()
            }
            isLoading = false
        }
    }

    // --- КОЛЛЕКЦИИ FIREBASE ---
    private fun getUserDocumentsCollection() = db.collection("users").document(auth.currentUser!!.uid).collection("documents")
    private fun getUsersMetadataCollection() = db.collection("users_metadata")
    private fun getAllDocumentsCollection() = db.collection("all_documents")

    // --- АУТЕНТИФИКАЦИЯ И МЕТАДАННЫЕ ---

    private fun saveUserMetadata(uid: String, email: String, displayName: String) = viewModelScope.launch {
        val metadata = UserMetadata(uid = uid, displayName = displayName, email = email)
        try {
            getUsersMetadataCollection().document(uid).set(metadata).await()
        } catch (e: Exception) {
            Log.e("Firestore", "Error saving user metadata: ${e.message}")
        }
    }

    fun signUp(email: String, password: String, displayName: String, onSuccess: () -> Unit, onError: (String) -> Unit) = viewModelScope.launch {
        try {
            val userCredential = auth.createUserWithEmailAndPassword(email, password).await()
            val user = userCredential.user
            user?.updateProfile(UserProfileChangeRequest.Builder().setDisplayName(displayName).build())?.await()

            if (user != null) {
                saveUserMetadata(user.uid, email, displayName)
            }
            onSuccess()
        } catch (e: Exception) {
            onError(e.message ?: "Ошибка регистрации")
        }
    }

    fun signIn(email: String, password: String, onSuccess: () -> Unit, onError: (String) -> Unit) = viewModelScope.launch {
        try {
            val userCredential = auth.signInWithEmailAndPassword(email, password).await()
            val user = userCredential.user
            if (user != null) {
                saveUserMetadata(user.uid, email, user.displayName ?: "Employee")
            }
            onSuccess()
        } catch (e: Exception) {
            onError(e.message ?: "Ошибка входа")
        }
    }

    fun signOut() {
        auth.signOut()
    }

    // --- ЛОГИКА ДЛЯ СОТРУДНИКА (Employee) ---

    // Загрузка активных документов
    private fun loadDocuments() {
        // Активные статусы: Черновик, Черновик (заполнен), На подпись директору
        getUserDocumentsCollection()
            .whereIn("status", listOf("Черновик", "Черновик (заполнен)", "На подпись директору"))
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.w("Firestore", "Active Documents Listen failed.", e)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    documents.clear()
                    for (doc in snapshot.documents) {
                        try {
                            val document = doc.toObject(Document::class.java)?.copy(id = doc.id)
                            if (document != null) {
                                documents.add(document)
                            }
                        } catch (e: Exception) {
                            Log.e("Firestore", "Error mapping document: ${doc.id}", e)
                        }
                    }
                }
            }
    }

    // Загрузка архивных документов
    private fun loadArchivedDocuments() {
        // Архивные статусы: Подписан, Отклонен
        getUserDocumentsCollection()
            .whereIn("status", listOf("Подписан", "Отклонен"))
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, e ->
                if (e != null) {
                    Log.w("Firestore", "Archived Documents Listen failed.", e)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    archivedDocuments.clear()
                    for (doc in snapshot.documents) {
                        try {
                            val document = doc.toObject(Document::class.java)?.copy(id = doc.id)
                            if (document != null) {
                                archivedDocuments.add(document)
                            }
                        } catch (e: Exception) {
                            Log.e("Firestore", "Error mapping document: ${doc.id}", e)
                        }
                    }
                }
            }
    }

    fun createDocument(title: String, type: String, onSuccess: () -> Unit, onError: (String) -> Unit) = viewModelScope.launch {
        val user = auth.currentUser
        if (user == null) {
            onError("Пользователь не авторизован")
            return@launch
        }

        // ... (логика создания полей) ...
        val initialFields = when (type) {
            "Договор" -> listOf(
                Field(id = "contractor", name = "Контрагент", type = FieldType.TEXT, required = true),
                Field(id = "date", name = "Дата подписания", type = FieldType.DATE, required = true),
                Field(id = "amount", name = "Сумма", type = FieldType.NUMBER),
                Field(id = "signature_empl", name = "Подпись сотрудника", type = FieldType.SIGNATURE)
            )
            "Счет-фактура" -> listOf(
                Field(id = "invoice_number", name = "Номер счета", type = FieldType.NUMBER, required = true),
                Field(id = "client", name = "Клиент", type = FieldType.TEXT, required = true),
                Field(id = "total", name = "Итоговая сумма", type = FieldType.NUMBER)
            )
            else -> listOf(
                Field(id = "main_text", name = "Основной текст", type = FieldType.TEXT, required = false)
            )
        }

        val newDocument = Document(
            userId = user.uid,
            userName = user.displayName ?: user.email ?: "Сотрудник",
            title = title,
            type = type,
            fields = initialFields
        )

        try {
            // Сохраняем в коллекцию пользователя
            val docRef = getUserDocumentsCollection().add(newDocument).await()
            val documentId = docRef.id

            // Копируем в общую коллекцию (для директора)
            getAllDocumentsCollection().document(documentId).set(newDocument.copy(id = documentId)).await()

            onSuccess()
        } catch (e: Exception) {
            onError(e.message ?: "Ошибка создания документа")
        }
    }

    // --- ОБЩАЯ ЛОГИКА ДОКУМЕНТОВ ---

    fun loadDocumentDetails(documentId: String, isDirector: Boolean = false) = viewModelScope.launch {
        val collection = if (isDirector) getAllDocumentsCollection() else getUserDocumentsCollection()
        val docRef = collection.document(documentId)

        // Используем onSnapshot для автоматического обновления деталей при сохранении
        docRef.addSnapshotListener { snapshot, e ->
            if (e != null) {
                Log.e("DocumentViewModel", "Error loading document details: ${e.message}")
                currentDocument = null
                currentDocumentFields.clear()
                return@addSnapshotListener
            }
            if (snapshot != null && snapshot.exists()) {
                val document = snapshot.toObject(Document::class.java)?.copy(id = snapshot.id)
                currentDocument = document

                currentDocumentFields.clear()
                if (document != null) {
                    currentDocumentFields.addAll(document.fields)
                }
            } else {
                Log.w("DocumentViewModel", "Document with ID $documentId not found.")
            }
        }
    }


    fun updateFieldValue(fieldId: String, newValue: String) {
        val index = currentDocumentFields.indexOfFirst { it.id == fieldId }
        if (index != -1) {
            val updatedField = currentDocumentFields[index].copy(value = newValue)
            currentDocumentFields[index] = updatedField
        }
    }

    // Сохранение изменений в документе (обновление полей) - используется сотрудником
    fun saveDocumentFields(onSuccess: () -> Unit, onError: (String) -> Unit) = viewModelScope.launch {
        val documentToSave = currentDocument ?: run {
            onError("Документ не загружен")
            return@launch
        }

        val updatedDocument = documentToSave.copy(
            fields = currentDocumentFields,
            status = if (documentToSave.status == "Черновик" && currentDocumentFields.all { !it.required || it.value.isNotBlank() }) "Черновик (заполнен)" else documentToSave.status
        )

        try {
            // Обновляем в коллекции пользователя
            getUserDocumentsCollection().document(updatedDocument.id).set(updatedDocument).await()
            // Обновляем в общей коллекции
            getAllDocumentsCollection().document(updatedDocument.id).set(updatedDocument).await()

            // currentDocument обновится автоматически через onSnapshot в loadDocumentDetails
            onSuccess()
        } catch (e: Exception) {
            onError(e.message ?: "Ошибка сохранения документа")
        }
    }

    // Отправка на подпись директору - используется сотрудником
    fun submitForApproval(onSuccess: () -> Unit, onError: (String) -> Unit) = viewModelScope.launch {
        val documentToUpdate = currentDocument ?: run {
            onError("Документ не загружен")
            return@launch
        }

        if (documentToUpdate.fields.any { it.required && it.value.isBlank() }) {
            onError("Невозможно отправить: не заполнены все обязательные поля!")
            return@launch
        }

        val updatedDocument = documentToUpdate.copy(
            status = "На подпись директору",
            fields = currentDocumentFields // Обновляем поля на всякий случай
        )

        try {
            // Обновляем в обеих коллекциях
            getUserDocumentsCollection().document(updatedDocument.id).set(updatedDocument).await()
            getAllDocumentsCollection().document(updatedDocument.id).set(updatedDocument).await()

            // currentDocument обновится автоматически через onSnapshot
            onSuccess()
        } catch (e: Exception) {
            onError(e.message ?: "Ошибка отправки на подпись")
        }
    }

    // --- ЛОГИКА ДЛЯ ДИРЕКТОРА (Admin) ---

    private fun loadAllEmployees() {
        getUsersMetadataCollection()
            .orderBy("displayName")
            .addSnapshotListener { snapshot, e ->
                // ... (логика загрузки всех сотрудников) ...
                if (e != null) {
                    Log.w("Firestore", "Employees Listen failed.", e)
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    userMetadata.clear()
                    for (doc in snapshot.documents) {
                        val user = doc.toObject(UserMetadata::class.java)
                        if (user != null) {
                            userMetadata.add(user)
                        }
                    }
                }
            }
    }

    private fun loadApprovalQueue() {
        getAllDocumentsCollection()
            .whereEqualTo("status", "На подпись директору")
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, e ->
                // ... (логика загрузки очереди на подпись) ...
                if (e != null) {
                    Log.w("Firestore", "Approval Queue Listen failed.", e)
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    approvalQueue.clear()
                    for (doc in snapshot.documents) {
                        try {
                            val document = doc.toObject(Document::class.java)?.copy(id = doc.id)
                            if (document != null) {
                                approvalQueue.add(document)
                            }
                        } catch (e: Exception) {
                            Log.e("Firestore", "Error mapping approval document: ${doc.id}", e)
                        }
                    }
                }
            }
    }

    fun updateDocumentStatus(documentId: String, newStatus: String, onSuccess: () -> Unit, onError: (String) -> Unit) = viewModelScope.launch {
        // ... (логика обновления статуса директором) ...
        val docRefAll = getAllDocumentsCollection().document(documentId)

        val document = docRefAll.get().await().toObject(Document::class.java) ?: run {
            onError("Документ не найден")
            return@launch
        }

        val docRefUser = db.collection("users").document(document.userId).collection("documents").document(documentId)

        try {
            // Обновляем статус в обеих коллекциях
            docRefAll.update("status", newStatus).await()
            docRefUser.update("status", newStatus).await()

            onSuccess()
        } catch (e: Exception) {
            onError(e.message ?: "Ошибка обновления статуса")
        }
    }
}

// --- ГЛАВНЫЙ КОМПОНЕНТ ---
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DocumentAppTheme {
                DocumentAppFlow()
            }
        }
    }
}

enum class Screen {
    AUTH,
    EMPLOYEE_DASHBOARD, // Главный экран сотрудника
    LIST, // Активные документы
    ARCHIVE, // Архив документов (Подписан, Отклонен)
    DETAIL, // Детали документа
    CREATE, // Экран создания
    CHAT, // Чат (заглушка)
    ADMIN_DASHBOARD, // Директор: дашборд с вкладками
    ADMIN_DETAIL // Директор: детали документа для утверждения
}

// --- УПРАВЛЕНИЕ НАВИГАЦИЕЙ ---
@Composable
fun DocumentAppFlow(viewModel: DocumentViewModel = viewModel()) {
    val currentScreen = remember { mutableStateOf(Screen.AUTH) }
    val selectedDocumentId = remember { mutableStateOf<String?>(null) }
    val authReady = !viewModel.isLoading

    LaunchedEffect(viewModel.isAuthenticated, viewModel.isAdmin, authReady) {
        if (authReady) {
            currentScreen.value = when {
                viewModel.isAuthenticated && viewModel.isAdmin -> Screen.ADMIN_DASHBOARD
                viewModel.isAuthenticated && !viewModel.isAdmin -> Screen.EMPLOYEE_DASHBOARD // Перенаправление на Дашборд
                else -> Screen.AUTH
            }
        }
    }

    if (!authReady) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        }
        return
    }

    val navigate: (Screen) -> Unit = { screen -> currentScreen.value = screen }
    val onDocumentClick: (String) -> Unit = { documentId ->
        selectedDocumentId.value = documentId
        currentScreen.value = Screen.DETAIL
    }
    val onAdminDocumentClick: (String) -> Unit = { documentId ->
        selectedDocumentId.value = documentId
        currentScreen.value = Screen.ADMIN_DETAIL
    }

    when (currentScreen.value) {
        Screen.AUTH -> AuthScreen(
            onSuccess = {
                currentScreen.value = if (viewModel.isAdmin) Screen.ADMIN_DASHBOARD else Screen.EMPLOYEE_DASHBOARD
            }
        )
        // Экраны для Сотрудника
        Screen.EMPLOYEE_DASHBOARD -> EmployeeDashboardScreen(
            viewModel = viewModel,
            onSignOut = { viewModel.signOut(); navigate(Screen.AUTH) },
            onNavigate = navigate
        )
        Screen.LIST -> DocumentListScreen(
            viewModel = viewModel,
            onBack = { navigate(Screen.EMPLOYEE_DASHBOARD) },
            onCreateNew = { navigate(Screen.CREATE) }, // Здесь происходит навигация
            onDocumentClick = onDocumentClick
        )
        Screen.ARCHIVE -> ArchiveListScreen(
            viewModel = viewModel,
            onBack = { navigate(Screen.EMPLOYEE_DASHBOARD) },
            onDocumentClick = onDocumentClick
        )
        Screen.CHAT -> ChatPlaceholderScreen(
            onBack = { navigate(Screen.EMPLOYEE_DASHBOARD) }
        )
        Screen.CREATE -> DocumentCreateScreen( // Здесь вызывается новый экран
            viewModel = viewModel,
            onBack = { navigate(Screen.LIST) },
            onDocumentCreated = { navigate(Screen.LIST) }
        )
        Screen.DETAIL -> {
            val docId = selectedDocumentId.value
            if (docId != null) {
                DocumentDetailScreen(
                    documentId = docId,
                    viewModel = viewModel,
                    onBack = { navigate(if (viewModel.currentDocument?.status == "Подписан" || viewModel.currentDocument?.status == "Отклонен") Screen.ARCHIVE else Screen.LIST) }
                )
            } else {
                navigate(Screen.EMPLOYEE_DASHBOARD)
            }
        }

        // Экраны для Директора
        Screen.ADMIN_DASHBOARD -> AdminDashboardScreen(
            viewModel = viewModel,
            onSignOut = { viewModel.signOut(); navigate(Screen.AUTH) },
            onDocumentClick = onAdminDocumentClick
        )
        Screen.ADMIN_DETAIL -> {
            val docId = selectedDocumentId.value
            if (docId != null) {
                AdminDocumentDetailScreen(
                    documentId = docId,
                    viewModel = viewModel,
                    onBack = { navigate(Screen.ADMIN_DASHBOARD) }
                )
            } else {
                navigate(Screen.ADMIN_DASHBOARD)
            }
        }
    }
}


// --- 1. ЭКРАН АУТЕНТИФИКАЦИИ ---
// ... (Оставлен без изменений)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    viewModel: DocumentViewModel = viewModel(),
    onSuccess: () -> Unit
) {
    var isSignUp by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var displayName by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        topBar = { TopAppBar(title = { Text(if (isSignUp) "Регистрация" else "Вход") }) },
        content = { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "DocumentApp",
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 32.dp)
                )

                if (isSignUp) {
                    OutlinedTextField(
                        value = displayName,
                        onValueChange = { displayName = it },
                        label = { Text("Имя пользователя") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    singleLine = true
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Пароль") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    singleLine = true
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }

                Button(
                    onClick = {
                        errorMessage = null
                        isLoading = true
                        coroutineScope.launch {
                            if (isSignUp) {
                                viewModel.signUp(email, password, displayName, onSuccess = onSuccess, onError = { errorMessage = it; isLoading = false })
                            } else {
                                viewModel.signIn(email, password, onSuccess = onSuccess, onError = { errorMessage = it; isLoading = false })
                            }
                        }
                    },
                    enabled = !isLoading && email.isNotBlank() && password.length >= 6 && (!isSignUp || displayName.isNotBlank()),
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(24.dp))
                    } else {
                        Text(if (isSignUp) "Зарегистрироваться" else "Войти")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                TextButton(
                    onClick = {
                        isSignUp = !isSignUp
                        errorMessage = null
                        email = ""
                        password = ""
                        displayName = ""
                    }
                ) {
                    Text(if (isSignUp) "Уже есть аккаунт? Войти" else "Нет аккаунта? Зарегистрироваться")
                }
            }
        }
    )
}

// --- 2. НОВЫЙ ЭКРАН ДАШБОРДА СОТРУДНИКА (С ПРИВЕТСТВИЕМ) ---
// ... (Оставлен без изменений)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EmployeeDashboardScreen(
    viewModel: DocumentViewModel,
    onSignOut: () -> Unit,
    onNavigate: (Screen) -> Unit
) {
    val userDisplayName = viewModel.userDisplayName ?: "Сотрудник"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Главная") },
                actions = {
                    IconButton(onClick = onSignOut) {
                        Icon(Icons.Filled.ExitToApp, contentDescription = "Выход")
                    }
                }
            )
        },
        content = { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Welcome message
                Text(
                    text = "Привет, $userDisplayName!",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
                )
                Text(
                    text = "Выберите, что вы хотите сделать:",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(bottom = 40.dp)
                )

                // Action Buttons
                DashboardActionButton(
                    title = "Мои Документы (${viewModel.documents.size})",
                    subtitle = "Черновики и документы на подписи",
                    icon = Icons.Filled.Description,
                    onClick = { onNavigate(Screen.LIST) }
                )
                Spacer(modifier = Modifier.height(16.dp))
                DashboardActionButton(
                    title = "Архив Документов (${viewModel.archivedDocuments.size})",
                    subtitle = "Просмотр подписанных и отклоненных",
                    icon = Icons.Filled.Archive,
                    onClick = { onNavigate(Screen.ARCHIVE) }
                )
                Spacer(modifier = Modifier.height(16.dp))
                DashboardActionButton(
                    title = "Чат с Сотрудниками",
                    subtitle = "Обсуждение документов и задач",
                    icon = Icons.Filled.Chat,
                    onClick = { onNavigate(Screen.CHAT) }
                )
            }
        }
    )
}

@Composable
fun DashboardActionButton(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(100.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer,
            contentColor = MaterialTheme.colorScheme.onPrimaryContainer
        ),
        elevation = CardDefaults.cardElevation(4.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                icon,
                contentDescription = title,
                modifier = Modifier.size(40.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}


// --- 3. ЭКРАН СПИСКА АКТИВНЫХ ДОКУМЕНТОВ (СОТРУДНИК) ---
// ... (Оставлен без изменений)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentListScreen(
    viewModel: DocumentViewModel,
    onBack: () -> Unit,
    onCreateNew: () -> Unit,
    onDocumentClick: (String) -> Unit
) {
    val documents = viewModel.documents

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Мои активные документы") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onCreateNew) {
                Icon(Icons.Filled.Add, contentDescription = "Создать документ")
            }
        },
        content = { padding ->
            if (documents.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    Text("Активных документов нет. Нажмите +, чтобы создать новый.")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(documents, key = { it.id }) { document ->
                        DocumentItem(document = document, onClick = onDocumentClick)
                    }
                }
            }
        }
    )
}

// --- 3.5. НОВЫЙ ЭКРАН СОЗДАНИЯ ДОКУМЕНТА (ИСПРАВЛЕНИЕ) ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentCreateScreen(
    viewModel: DocumentViewModel,
    onBack: () -> Unit,
    onDocumentCreated: () -> Unit
) {
    var title by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(DocumentTypes.first()) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var isExpanded by remember { mutableStateOf(false) }

    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Создание нового документа") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
            )
        },
        content = { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                // Поле для ввода названия
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название документа") },
                    leadingIcon = { Icon(Icons.Default.DriveFileRenameOutline, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                    singleLine = true
                )

                // Выбор типа документа (Dropdown)
                ExposedDropdownMenuBox(
                    expanded = isExpanded,
                    onExpandedChange = { isExpanded = !isExpanded },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp)
                ) {
                    OutlinedTextField(
                        readOnly = true,
                        value = selectedType,
                        onValueChange = { },
                        label = { Text("Тип документа") },
                        trailingIcon = {
                            ExposedDropdownMenuDefaults.TrailingIcon(
                                expanded = isExpanded
                            )
                        },
                        colors = ExposedDropdownMenuDefaults.textFieldColors(),
                        modifier = Modifier.menuAnchor().fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = isExpanded,
                        onDismissRequest = { isExpanded = false }
                    ) {
                        DocumentTypes.forEach { selectionOption ->
                            DropdownMenuItem(
                                text = { Text(selectionOption) },
                                onClick = {
                                    selectedType = selectionOption
                                    isExpanded = false
                                }
                            )
                        }
                    }
                }

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )
                }

                // Кнопка создания документа
                Button(
                    onClick = {
                        isLoading = true
                        errorMessage = null
                        coroutineScope.launch {
                            viewModel.createDocument(title, selectedType,
                                onSuccess = {
                                    isLoading = false
                                    onDocumentCreated()
                                },
                                onError = {
                                    errorMessage = it
                                    isLoading = false
                                }
                            )
                        }
                    },
                    enabled = !isLoading && title.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(24.dp))
                    } else {
                        Text("Создать документ")
                    }
                }
            }
        }
    )
}

// --- 4. НОВЫЙ ЭКРАН АРХИВА ДОКУМЕНТОВ (СОТРУДНИК) ---
// ... (Оставлен без изменений)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArchiveListScreen(
    viewModel: DocumentViewModel,
    onBack: () -> Unit,
    onDocumentClick: (String) -> Unit
) {
    val documents = viewModel.archivedDocuments

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Архив (Подписаны/Отклонены)") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
            )
        },
        content = { padding ->
            if (documents.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                    Text("Архив пуст.")
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(documents, key = { it.id }) { document ->
                        DocumentItem(document = document, onClick = onDocumentClick)
                    }
                }
            }
        }
    )
}

// --- 5. ЭКРАН ДЕТАЛЕЙ ДОКУМЕНТА (СОТРУДНИК) ---
// ... (Оставлен без изменений)
@OptIn(ExperimentalMaterial3Api::class)

@Composable
fun DocumentDetailScreen(
    documentId: String,
    viewModel: DocumentViewModel,
    onBack: () -> Unit
) {
    // onSnapshot в ViewModel обеспечивает автоматическое обновление.
    LaunchedEffect(documentId) {
        viewModel.loadDocumentDetails(documentId)
    }

    val document = viewModel.currentDocument
    val fields = viewModel.currentDocumentFields
    val coroutineScope = rememberCoroutineScope()
    var showSaveSuccess by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }

    if (document == null) {
        Scaffold(topBar = { TopAppBar(title = { Text("Загрузка...") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Назад") } }) }) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        }
        return
    }

    // Определяем, можно ли редактировать/сохранять
    val isEditable = document.status == "Черновик" || document.status == "Черновик (заполнен)" || document.status == "Отклонен"
    val isReadyForSubmit = fields.all { !it.required || it.value.isNotBlank() }
    val isArchived = document.status == "Подписан"
    val isSentForApproval = document.status == "На подпись директору"


    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(document.title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    if (!isArchived) {
                        DocumentShareButton(document = document) // Кнопка "Поделиться"
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    if (isEditable) {
                        // Кнопка сохранения
                        Button(
                            onClick = {
                                isSaving = true
                                errorMessage = null
                                coroutineScope.launch {
                                    viewModel.saveDocumentFields(
                                        onSuccess = {
                                            showSaveSuccess = true
                                            isSaving = false
                                        },
                                        onError = {
                                            errorMessage = it
                                            isSaving = false
                                        }
                                    )
                                }
                            },
                            enabled = !isSaving
                        ) {
                            Text(if (isSaving) "..." else "Сохранить")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                }
            )
        },
        content = { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                // Блок с информацией о статусе
                DocumentStatusCard(document = document)

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 16.dp).padding(bottom = 8.dp)
                    )
                }

                // Сообщение об успешном сохранении
                if (showSaveSuccess) {
                    LaunchedEffect(Unit) {
                        kotlinx.coroutines.delay(3000)
                        showSaveSuccess = false
                    }
                    SuccessMessageCard(text = if (isSentForApproval) "Документ отправлен на подпись!" else "Документ успешно сохранен!")
                }

                // Кнопка отправки на подпись (если не отправлен и не архив)
                if (isEditable || document.status == "Черновик (заполнен)") {
                    Button(
                        onClick = {
                            isSaving = true
                            errorMessage = null
                            coroutineScope.launch {
                                viewModel.submitForApproval(
                                    onSuccess = {
                                        isSaving = false
                                        showSaveSuccess = true
                                    },
                                    onError = {
                                        errorMessage = it
                                        isSaving = false
                                    }
                                )
                            }
                        },
                        enabled = isReadyForSubmit && !isSaving,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp)
                    ) {
                        Text(if (isSaving) "Отправка..." else "Отправить на подпись Директору")
                    }
                } else if (isSentForApproval) {
                    Text(
                        text = "Ожидание подписи Директора. Изменения невозможны.",
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 16.dp)
                    )
                }

                // Список полей для заполнения
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(fields, key = { it.id }) { field ->
                        FieldEditor(
                            field = field,
                            onValueChange = { newValue ->
                                if (isEditable) {
                                    viewModel.updateFieldValue(field.id, newValue)
                                }
                            },
                            readOnly = !isEditable // Только если статус позволяет
                        )
                    }
                }
            }
        }
    )
}

// --- 6. НОВЫЙ ЭКРАН-ЗАГЛУШКА ДЛЯ ЧАТА ---
// ... (Оставлен без изменений)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatPlaceholderScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Чат с Сотрудниками") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
            )
        },
        content = { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Filled.Construction,
                        contentDescription = "В разработке",
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Функционал чата находится в разработке.",
                        style = MaterialTheme.typography.titleMedium,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Здесь будет реализована возможность обмена сообщениями и документами между сотрудниками.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    )
}

// --- 7. КОМПОНЕНТЫ ДЛЯ ОБМЕНА ДОКУМЕНТАМИ ---
// ... (Оставлен без изменений)
@Composable
fun DocumentShareButton(document: Document) {
    var showShareDialog by remember { mutableStateOf(false) }

    IconButton(onClick = { showShareDialog = true }) {
        Icon(Icons.Filled.Share, contentDescription = "Поделиться")
    }

    if (showShareDialog) {
        ShareDocumentDialog(
            document = document,
            onDismiss = { showShareDialog = false }
        )
    }
}

@Composable
fun ShareDocumentDialog(
    document: Document,
    onDismiss: () -> Unit
) {
    var recipientEmail by remember { mutableStateOf("") }
    var shareStatus by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Поделиться документом: ${document.title}") },
        text = {
            Column {
                Text("Введите email сотрудника, с которым хотите поделиться доступом:", style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = recipientEmail,
                    onValueChange = { recipientEmail = it },
                    label = { Text("Email сотрудника") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )
                shareStatus?.let {
                    Text(it, color = if (it.contains("успешно")) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    isLoading = true
                    shareStatus = null

                    if (recipientEmail.isBlank() || !android.util.Patterns.EMAIL_ADDRESS.matcher(recipientEmail).matches()) {
                        shareStatus = "Пожалуйста, введите корректный email."
                        isLoading = false
                        return@Button
                    }

                    // Имитация успешной отправки ссылки на документ (заглушка для реального обмена доступом)
                    shareStatus = "Доступ к документу успешно предоставлен пользователю ${recipientEmail}."
                    isLoading = false
                    recipientEmail = ""
                },
                enabled = !isLoading && recipientEmail.isNotBlank() && shareStatus?.contains("успешно") != true
            ) {
                if (isLoading) CircularProgressIndicator(Modifier.size(20.dp), color = MaterialTheme.colorScheme.onPrimary)
                else Text("Предоставить доступ")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Закрыть")
            }
        }
    )
}

// --- 8. ЭКРАНЫ ДИРЕКТОРА (Администратора) ---
// ... (Оставлен без изменений)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminDashboardScreen(
    viewModel: DocumentViewModel,
    onSignOut: () -> Unit,
    onDocumentClick: (String) -> Unit
) {
    val userDisplayName = viewModel.userDisplayName
    val tabs = listOf("На подпись (${viewModel.approvalQueue.size})", "Сотрудники (${viewModel.userMetadata.size})")
    var selectedTabIndex by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Дашборд Директора") },
                actions = {
                    Text("Директор: $userDisplayName", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.align(Alignment.CenterVertically))
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(onClick = onSignOut) {
                        Icon(Icons.Filled.ExitToApp, contentDescription = "Выход")
                    }
                }
            )
        },
        content = { padding ->
            Column(modifier = Modifier.fillMaxSize().padding(padding)) {

                // Вкладки
                TabRow(selectedTabIndex = selectedTabIndex) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTabIndex == index,
                            onClick = { selectedTabIndex = index },
                            text = { Text(title) }
                        )
                    }
                }

                // Контент вкладок
                when (selectedTabIndex) {
                    0 -> ApprovalQueueScreen(viewModel = viewModel, onDocumentClick = onDocumentClick)
                    1 -> EmployeeListScreen(viewModel = viewModel)
                }
            }
        }
    )
}

@Composable
fun EmployeeListScreen(viewModel: DocumentViewModel) {
    val employees = viewModel.userMetadata
    // ... (логика отображения списка сотрудников) ...
    if (employees.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            Text("Список сотрудников пуст.")
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(employees, key = { it.uid }) { employee ->
            Card(modifier = Modifier.fillMaxWidth(), elevation = CardDefaults.cardElevation(1.dp)) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.AccountCircle, contentDescription = "Сотрудник", tint = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(employee.displayName, fontWeight = FontWeight.Medium)
                        Text(employee.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun ApprovalQueueScreen(viewModel: DocumentViewModel, onDocumentClick: (String) -> Unit) {
    val documents = viewModel.approvalQueue
    // ... (логика отображения очереди на подпись) ...
    if (documents.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            Text("Нет документов, ожидающих подписи.")
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(documents, key = { it.id }) { document ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onDocumentClick(document.id) },
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.Assignment,
                        contentDescription = "Документ",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = document.title,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "От: ${document.userName}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Text(
                        text = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(document.createdAt)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)

@Composable
fun AdminDocumentDetailScreen(
    documentId: String,
    viewModel: DocumentViewModel,
    onBack: () -> Unit
) {
    LaunchedEffect(documentId) {
        viewModel.loadDocumentDetails(documentId, isDirector = true)
    }

    val document = viewModel.currentDocument
    val fields = viewModel.currentDocumentFields
    val coroutineScope = rememberCoroutineScope()
    var isProcessing by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    if (document == null) {
        Scaffold(topBar = { TopAppBar(title = { Text("Загрузка...") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Назад") } }) }) { padding ->
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
        }
        return
    }

    val requiresApproval = document.status == "На подпись директору"

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(document.title) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                    }
                }
            )
        },
        bottomBar = {
            if (requiresApproval) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Button(
                        onClick = {
                            isProcessing = true
                            errorMessage = null
                            coroutineScope.launch {
                                viewModel.updateDocumentStatus(documentId, "Подписан",
                                    onSuccess = { isProcessing = false; onBack() },
                                    onError = { errorMessage = it; isProcessing = false }
                                )
                            }
                        },
                        enabled = !isProcessing,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        if (isProcessing) CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White) else Text("Подписать")
                    }
                    OutlinedButton(
                        onClick = {
                            isProcessing = true
                            errorMessage = null
                            coroutineScope.launch {
                                viewModel.updateDocumentStatus(documentId, "Отклонен",
                                    onSuccess = { isProcessing = false; onBack() },
                                    onError = { errorMessage = it; isProcessing = false }
                                )
                            }
                        },
                        enabled = !isProcessing,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD32F2F)),
                        border = BorderStroke(1.dp, Color(0xFFD32F2F))
                    ) {
                        Text("Отклонить")
                    }
                }
            }
        },
        content = { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                // Блок с информацией о статусе
                DocumentStatusCard(document = document, extraInfo = "От: ${document.userName}")

                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(horizontal = 16.dp).padding(bottom = 8.dp)
                    )
                }

                // Список полей (только для просмотра)
                LazyColumn(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(fields, key = { it.id }) { field ->
                        FieldEditor(
                            field = field,
                            onValueChange = { /* Только просмотр */ },
                            readOnly = true // Директор не редактирует поля
                        )
                    }
                }
            }
        }
    )
}

// --- ВСПОМОГАТЕЛЬНЫЕ КОМПОНЕНТЫ ---
// ... (Оставлены без изменений)
@Composable
fun DocumentItem(document: Document, onClick: (String) -> Unit) {
    val statusColor = when (document.status) {
        "Подписан" -> Color(0xFF2E7D32)
        "На подпись директору" -> MaterialTheme.colorScheme.primary // Оранжевый
        "Отклонен" -> Color(0xFFD32F2F)
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick(document.id) },
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Filled.Description,
                contentDescription = "Документ",
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = document.title,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "Тип: ${document.type}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = document.status,
                    style = MaterialTheme.typography.bodySmall,
                    color = statusColor,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(document.createdAt)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun DocumentStatusCard(document: Document, extraInfo: String? = null) {
    val (color, contentColor) = when (document.status) {
        "Подписан" -> Color(0xFFE8F5E9) to Color(0xFF2E7D32)
        "На подпись директору" -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.primary
        "Отклонен" -> Color(0xFFFFEBEE) to Color(0xFFD32F2F)
        else -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = color, contentColor = contentColor)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "Тип: ${document.type}",
                fontWeight = FontWeight.Normal,
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = "Статус: ${document.status}",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            extraInfo?.let {
                Text(
                    text = it,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
fun SuccessMessageCard(text: String) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .padding(bottom = 8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(12.dp),
            color = MaterialTheme.colorScheme.onTertiaryContainer,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
fun FieldEditor(field: Field, onValueChange: (String) -> Unit, readOnly: Boolean = false) {
    // ... (логика FieldEditor) ...
    when (field.type) {
        FieldType.TEXT -> {
            OutlinedTextField(
                value = field.value,
                onValueChange = onValueChange,
                label = { Text("${field.name} ${if (field.required) "*" else ""}") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = field.required && field.value.isBlank() && !readOnly,
                readOnly = readOnly
            )
            if (field.required && field.value.isBlank() && !readOnly) {
                Text(
                    text = "Поле обязательно для заполнения",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(start = 16.dp, top = 4.dp)
                )
            }
        }
        FieldType.NUMBER -> {
            OutlinedTextField(
                value = field.value,
                onValueChange = { if (it.all { char -> char.isDigit() || char == '.' }) onValueChange(it) },
                label = { Text("${field.name} ${if (field.required) "*" else ""}") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = field.required && field.value.isBlank() && !readOnly,
                readOnly = readOnly
            )
            if (field.required && field.value.isBlank() && !readOnly) {
                Text(
                    text = "Поле обязательно для заполнения",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(start = 16.dp, top = 4.dp)
                )
            }
        }
        FieldType.DATE -> {
            OutlinedTextField(
                value = field.value,
                onValueChange = onValueChange,
                label = { Text("${field.name} (ДД.ММ.ГГГГ) ${if (field.required) "*" else ""}") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                isError = field.required && field.value.isBlank() && !readOnly,
                readOnly = readOnly
            )
            if (field.required && field.value.isBlank() && !readOnly) {
                Text(
                    text = "Поле обязательно для заполнения",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(start = 16.dp, top = 4.dp)
                )
            }
        }
        FieldType.SIGNATURE -> {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(8.dp))
                    .padding(16.dp)
            ) {
                Text(
                    text = field.name,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium
                )
                if (field.value.isEmpty()) {
                    Text("Подпись отсутствует", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                } else {
                    Text("Подписано: ${field.value}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }

                if (!readOnly) {
                    Button(
                        onClick = {
                            onValueChange("${field.name} ${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())}")
                        },
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        Text(if (field.value.isEmpty()) "Добавить подпись" else "Изменить подпись")
                    }
                }
            }
        }
    }
}


// --- ТЕМА И ПРЕВЬЮ (ОБНОВЛЕННЫЕ) ---
// ... (Оставлены без изменений)

// Определяем кастомную цветовую схему
val PrimaryOrange = Color(0xFFFF9800) // Deep Orange
val SecondaryYellow = Color(0xFFFFC107) // Amber
val TertiaryBrown = Color(0xFF795548) // Brown for contrast

val LightColorScheme = lightColorScheme(
    primary = PrimaryOrange,
    secondary = SecondaryYellow,
    tertiary = TertiaryBrown,
    background = Color(0xFFFFF3E0), // Light cream background
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onTertiary = Color.White,
    onBackground = Color.Black,
    onSurface = Color.Black,
    error = Color(0xFFB00020),
    // Используем оранжевый для основных действий и контейнеров
    primaryContainer = PrimaryOrange.copy(alpha = 0.15f),
    onPrimaryContainer = PrimaryOrange,
    tertiaryContainer = SecondaryYellow.copy(alpha = 0.3f),
    onTertiaryContainer = TertiaryBrown,
    surfaceVariant = Color(0xFFFBE4B9) // Желтоватый оттенок для карточек
)

@Composable
fun DocumentAppTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        darkTheme -> darkColorScheme() // Можно настроить и темную
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography(),
        content = content
    )
}

@Preview(showBackground = true)
@Composable
fun DocumentAppPreview() {
    DocumentAppTheme {
        DocumentItem(
            document = Document(
                id = "test",
                title = "Договор №123",
                status = "На подпись директору",
                type = "Договор",
                createdAt = System.currentTimeMillis()
            ),
            onClick = {}
        )
    }
}