pluginManagement {
    repositories {
        google() // ОЧЕНЬ ВАЖНО для Compose, Firebase и других библиотек Google
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google() // ОЧЕНЬ ВАЖНО
        mavenCentral()
    }
}

rootProject.name = "linarrra"
include(":app")