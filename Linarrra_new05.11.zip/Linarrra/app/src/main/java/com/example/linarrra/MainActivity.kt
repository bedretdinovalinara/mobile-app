package com.example.linarrra

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.BorderStroke // Добавлен import для BorderStroke
// Import для coroutines.delay, который лучше разрешается в LaunchedEffect
import kotlinx.coroutines.delay // Явный импорт для обеспечения разрешения

// --- 1. ТЕМА ПРИЛОЖЕНИЯ ---

@Composable
fun DocumentAppTheme(content: @Composable () -> Unit) {
    // Используем стандартные цвета Material Design 3
    val colors = lightColorScheme(
        // Оранжевый (Primary)
        primary = Color(0xFFFF5722), // Глубокий оранжевый
        onPrimary = Color.White,
        primaryContainer = Color(0xFFFFCCBC), // Светло-оранжевый (TopBar Background)
        onPrimaryContainer = Color(0xFF4C0F00), // Темный (TopBar Text)

        // Красный/Розовый (Secondary/Accent)
        secondary = Color(0xFFE91E63), // Яркий розово-красный
        onSecondary = Color.White,

        // Синий (Tertiary - для дополнительного акцента, чтобы разделить оранжевые карточки)
        tertiary = Color(0xFF00BCD4), // Светло-голубой
        onTertiary = Color.White,

        // Фон и поверхности (Белый)
        background = Color(0xFFFAFAFA), // Очень светлый фон для контраста
        surface = Color.White
    )
    MaterialTheme(
        colorScheme = colors,
        typography = MaterialTheme.typography,
        content = content
    )
}

// --- 2. ГЛАВНАЯ АКТИВНОСТЬ ---

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DocumentAppTheme {
                DocumentAppFlow()
            }
        }
    }
}

// --- 3. ГЛАВНЫЙ ПОТОК (CONTAINER) ---

// Состояния, описывающие основной поток приложения
enum class AppState {
    AUTH,           // Вход / Регистрация
    FEATURES,       // Обзор возможностей (онбординг)
    FUNCTION_SELECTION, // Выбор главной функции
    DOCUMENT_FILLING,   // Заполнение документа
    MAIN_APP        // Основной рабочий экран (заглушка)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentAppFlow() {
    // Состояние, которое определяет текущий главный экран
    var appState by remember { mutableStateOf(AppState.AUTH) }
    // Временно для тестирования можно установить AppState.FUNCTION_SELECTION

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = when (appState) {
                            AppState.AUTH, AppState.FEATURES -> "Электронный документооборот"
                            AppState.FUNCTION_SELECTION -> "Выбор функции"
                            AppState.DOCUMENT_FILLING -> "Заполнение документа"
                            AppState.MAIN_APP -> "Рабочий стол"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    if (appState == AppState.DOCUMENT_FILLING) {
                        IconButton(onClick = { appState = AppState.FUNCTION_SELECTION }) {
                            Icon(Icons.Filled.ArrowBack, contentDescription = "Назад к выбору функций")
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        // Добавляем вертикальную прокрутку для всего контента под TopBar
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            when (appState) {
                AppState.AUTH -> DocumentAuthContent(
                    onLoginSuccess = { appState = AppState.FEATURES }
                )
                AppState.FEATURES -> FeaturesOverviewScreen(
                    onFinishOnboarding = { appState = AppState.FUNCTION_SELECTION } // Переход к выбору функций
                )
                AppState.FUNCTION_SELECTION -> FunctionSelectionScreen(
                    onSelectFillDocument = { appState = AppState.DOCUMENT_FILLING },
                    onSelectSendDocument = { appState = AppState.MAIN_APP }, // Заглушка
                    onSelectArchive = { appState = AppState.MAIN_APP } // Заглушка
                )
                AppState.DOCUMENT_FILLING -> DocumentFillingScreen(
                    onBack = { appState = AppState.FUNCTION_SELECTION }
                )
                AppState.MAIN_APP -> MainDocumentScreen() // Используется как заглушка
            }
        }
    }
}


// --- 4. КОНТЕНТ АУТЕНТИФИКАЦИИ ---
enum class AuthScreen {
    LOGIN,
    REGISTRATION
}

@Composable
fun DocumentAuthContent(onLoginSuccess: () -> Unit) {
    var currentScreen by remember { mutableStateOf(AuthScreen.LOGIN) }

    val onRegistrationSuccess = {
        currentScreen = AuthScreen.LOGIN
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        when (currentScreen) {
            AuthScreen.LOGIN -> LoginScreen(
                onNavigateToRegistration = { currentScreen = AuthScreen.REGISTRATION },
                onLoginSuccess = onLoginSuccess
            )
            AuthScreen.REGISTRATION -> RegistrationScreen(
                onNavigateToLogin = { currentScreen = AuthScreen.LOGIN },
                onRegistrationSuccess = onRegistrationSuccess
            )
        }
    }
}


// --- 5. ЭКРАН ВХОДА ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(onNavigateToRegistration: () -> Unit, onLoginSuccess: () -> Unit) {
    var email by remember { mutableStateOf("test@mail.ru") }
    var password by remember { mutableStateOf("password") }
    var passwordVisible by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Добро пожаловать!",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Электронная почта") },
                leadingIcon = { Icon(Icons.Filled.Email, contentDescription = "Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Пароль") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Пароль") },
                trailingIcon = {
                    val image = if (passwordVisible)
                        Icons.Filled.Visibility
                    else Icons.Filled.VisibilityOff

                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(imageVector = image, contentDescription = "Показать/скрыть пароль")
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    if (email.isNotEmpty() && password.isNotEmpty()) {
                        onLoginSuccess()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Войти", fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Нет аккаунта? Зарегистрироваться",
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clickable(onClick = onNavigateToRegistration)
                    .padding(8.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

// --- 6. ЭКРАН РЕГИСТРАЦИИ ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrationScreen(onNavigateToLogin: () -> Unit, onRegistrationSuccess: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Регистрация",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Имя пользователя") },
                leadingIcon = { Icon(Icons.Filled.Person, contentDescription = "Имя") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Электронная почта") },
                leadingIcon = { Icon(Icons.Filled.Email, contentDescription = "Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Пароль") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Пароль") },
                trailingIcon = {
                    val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(imageVector = image, contentDescription = "Показать/скрыть пароль")
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text("Подтвердить пароль") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Подтвердить пароль") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = {
                    if (password == confirmPassword && email.isNotEmpty()) {
                        onRegistrationSuccess()
                    } else if (password != confirmPassword) {
                        println("Пароли не совпадают")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Text("Зарегистрироваться", fontSize = 18.sp)
            }

            Text(
                text = "Уже есть аккаунт? Войти",
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier
                    .clickable(onClick = onNavigateToLogin)
                    .padding(8.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}


// --- 7. КОМПОНЕНТ КАРТОЧКИ ВОЗМОЖНОСТЕЙ ---

data class Feature(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val accentColor: Color // Имя параметра для цвета акцента
)

@Composable
fun FeatureCard(feature: Feature) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .height(400.dp)
            .padding(16.dp),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            if (feature.title.isNotEmpty()) {
                Text(
                    text = feature.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = feature.accentColor,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
            } else {
                Spacer(modifier = Modifier.height(10.dp))
            }


            // Иконка/Иллюстрация
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(feature.accentColor.copy(alpha = 0.1f))
                    .border(2.dp, feature.accentColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = feature.icon,
                    contentDescription = feature.description,
                    tint = feature.accentColor,
                    modifier = Modifier.size(80.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Описание функции
            Text(
                text = feature.description,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Заглушка для аватара пользователя
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.Gray)
                    .align(Alignment.End)
            ) {
                Icon(
                    Icons.Filled.AccountCircle,
                    contentDescription = "User Avatar Placeholder",
                    tint = Color.White,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}


// --- 8. ЭКРАН ОБЗОРА ВОЗМОЖНОСТЕЙ (ОНБОРДИНГ) ---

@Composable
fun FeaturesOverviewScreen(onFinishOnboarding: () -> Unit) {
    val features = listOf(
        Feature(
            title = "С ВОЗВРАЩЕНИЕМ!",
            description = "Здесь вы можете создать или загрузить документ, а также загрузить его в облако компании.",
            icon = Icons.Filled.Description,
            accentColor = MaterialTheme.colorScheme.primary
        ),
        Feature(
            title = "",
            description = "Отправляйте документы коллегам и получайте от них письма. Вся коммуникация в одном месте.",
            icon = Icons.Filled.People,
            accentColor = MaterialTheme.colorScheme.secondary
        ),
        Feature(
            title = "",
            description = "Архивируйте документы, вы сможете скачать их в любой момент для дальнейшей работы!",
            icon = Icons.Filled.Archive,
            accentColor = MaterialTheme.colorScheme.tertiary
        )
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceAround
    ) {

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(features) { feature ->
                FeatureCard(feature = feature)
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = onFinishOnboarding,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Начать работу", fontSize = 18.sp)
        }
    }
}

// --- 9. ЭКРАН ВЫБОРА ГЛАВНОЙ ФУНКЦИИ (НОВЫЙ ХАБ) ---

@Composable
fun FunctionSelectionScreen(
    onSelectFillDocument: () -> Unit,
    onSelectSendDocument: () -> Unit,
    onSelectArchive: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Text(
            text = "Выберите, что вы хотите сделать",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        // Кнопка: Заполнение документа
        SelectionButton(
            title = "Заполнить документ",
            description = "Создание нового документа по шаблону.",
            icon = Icons.Filled.Edit,
            iconColor = MaterialTheme.colorScheme.primary,
            onClick = onSelectFillDocument
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Кнопка: Отправка документа
        SelectionButton(
            title = "Отправить документ",
            description = "Пересылка документа на согласование или подписание.",
            icon = Icons.Filled.Send,
            iconColor = MaterialTheme.colorScheme.secondary,
            onClick = onSelectSendDocument
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Кнопка: Архив
        SelectionButton(
            title = "Архив и поиск",
            description = "Просмотр и скачивание завершенных документов.",
            icon = Icons.Filled.Folder,
            iconColor = MaterialTheme.colorScheme.tertiary,
            onClick = onSelectArchive
        )
    }
}

// Вспомогательный компонент для кнопок выбора
@Composable
fun SelectionButton(title: String, description: String, icon: ImageVector, iconColor: Color, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconColor,
                modifier = Modifier
                    .size(48.dp)
                    .padding(end = 16.dp)
            )
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// --- НОВЫЕ СТРУКТУРЫ ДАННЫХ ДЛЯ ШАБЛОНОВ ---

// Дата-класс для описания шаблона документа
data class Template(
    val id: String,
    val name: String,
    val icon: ImageVector,
    val fields: List<FieldType>
)

// Перечисление для типов полей, необходимых для заполнения
enum class FieldType {
    TEXT, NUMBER, DATE, FULL_NAME, PASSPORT_ID
}

// Список доступных шаблонов
val documentTemplates = listOf(
    Template(
        id = "passport",
        name = "Паспорт РФ",
        icon = Icons.Filled.Book,
        fields = listOf(FieldType.PASSPORT_ID, FieldType.FULL_NAME, FieldType.DATE)
    ),
    Template(
        id = "gph_contract",
        name = "Договор ГПХ",
        icon = Icons.Filled.Work,
        fields = listOf(FieldType.FULL_NAME, FieldType.TEXT, FieldType.NUMBER, FieldType.DATE)
    ),
    Template(
        id = "sale_contract",
        name = "Договор купли-продажи",
        icon = Icons.Filled.AccountBalance,
        fields = listOf(FieldType.FULL_NAME, FieldType.TEXT, FieldType.NUMBER, FieldType.DATE)
    )
)

// --- 10. ЭКРАН ЗАПОЛНЕНИЯ ДОКУМЕНТА (ОБНОВЛЕННЫЙ) ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentFillingScreen(onBack: () -> Unit) {
    // Состояние, чтобы выбрать шаблон (по умолчанию, первый в списке)
    var selectedTemplate by remember { mutableStateOf(documentTemplates.first()) }
    var isScanning by remember { mutableStateOf(false) } // Состояние для имитации сканирования

    // Хранение данных для полей выбранного шаблона
    val fieldValues = remember { mutableStateMapOf<FieldType, String>() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Text(
            text = "Заполнение документа: ${selectedTemplate.name}",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 24.dp),
            color = MaterialTheme.colorScheme.primary
        )

        // 1. ВЫБОР ШАБЛОНА
        Text("Выберите шаблон:", style = MaterialTheme.typography.titleMedium, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(documentTemplates) { template ->
                TemplateChip(
                    template = template,
                    isSelected = template.id == selectedTemplate.id,
                    onClick = {
                        selectedTemplate = template
                        // Очищаем поля при смене шаблона
                        fieldValues.clear()
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 2. КНОПКА СКАНИРОВАНИЯ
        OutlinedButton(
            onClick = { isScanning = true /* Имитация запуска камеры */ },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.secondary)
        ) {
            Icon(Icons.Filled.CameraAlt, contentDescription = "Сканировать", modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Сканировать документ через камеру", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        }

        // Индикатор сканирования (заглушка)
        if (isScanning) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            Text("Сканирование и распознавание...", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            // Имитация завершения сканирования через 2 секунды
            LaunchedEffect(Unit) {
                delay(2000) // Исправлено: удален префикс kotlinx.coroutines.
                isScanning = false
                // Заполняем поля заглушками после сканирования
                selectedTemplate.fields.forEach { type ->
                    fieldValues[type] = getMockScannedValue(type)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 3. ПОЛЯ ДЛЯ ЗАПОЛНЕНИЯ
        Text("Поля для заполнения:", style = MaterialTheme.typography.titleMedium, modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp))

        selectedTemplate.fields.forEach { fieldType ->
            DocumentInputField(
                fieldType = fieldType,
                value = fieldValues[fieldType] ?: "",
                onValueChange = { newValue -> fieldValues[fieldType] = newValue }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Кнопка: Сформировать документ
        Button(
            onClick = { /* TODO: Логика формирования и сохранения документа */ },
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Сформировать и сохранить", fontSize = 18.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Кнопка: Отмена
        OutlinedButton(
            onClick = onBack,
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.onSurfaceVariant)
        ) {
            Text("Отмена", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// --- ВСПОМОГАТЕЛЬНЫЕ КОМПОНЕНТЫ ДЛЯ DocumentFillingScreen ---

// Компонент-чип для выбора шаблона
@Composable
fun TemplateChip(template: Template, isSelected: Boolean, onClick: () -> Unit) {
    AssistChip(
        onClick = onClick,
        label = { Text(template.name) },
        leadingIcon = { Icon(template.icon, contentDescription = template.name, modifier = Modifier.size(18.dp)) },
        colors = AssistChipDefaults.assistChipColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
            labelColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
            leadingIconContentColor = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        ),
        border = if (isSelected) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    )
}

// Компонент поля ввода в зависимости от типа FieldType
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentInputField(fieldType: FieldType, value: String, onValueChange: (String) -> Unit) {
    val (label, icon, keyboardType) = when (fieldType) {
        FieldType.TEXT -> Triple("Текстовое поле", Icons.Filled.TextFields, KeyboardType.Text)
        FieldType.NUMBER -> Triple("Числовое значение", Icons.Filled.Numbers, KeyboardType.Number)
        FieldType.DATE -> Triple("Дата (ДД.ММ.ГГГГ)", Icons.Filled.CalendarToday, KeyboardType.Number)
        FieldType.FULL_NAME -> Triple("ФИО полностью", Icons.Filled.Person, KeyboardType.Text)
        FieldType.PASSPORT_ID -> Triple("Серия и номер паспорта", Icons.Filled.CreditCard, KeyboardType.Number)
    }

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        leadingIcon = { Icon(icon, contentDescription = label) },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp)
    )
}

// Функция-заглушка для имитации распознанных данных
fun getMockScannedValue(type: FieldType): String {
    return when (type) {
        FieldType.TEXT -> "Распознанный текст"
        FieldType.NUMBER -> "100000"
        FieldType.DATE -> "05.11.2025"
        FieldType.FULL_NAME -> "Иванов Иван Иванович"
        FieldType.PASSPORT_ID -> "4501 123456"
    }
}

// --- 11. ГЛАВНЫЙ РАБОЧИЙ ЭКРАН (ЗАГЛУШКА) ---

@Composable
fun MainDocumentScreen() {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Filled.Info,
            contentDescription = "Placeholder",
            tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.size(96.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Функция в разработке",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Этот экран будет содержать логику отправки/архива.",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

// --- 12. ПРЕВЬЮ ---

@Preview(showBackground = true)
@Composable
fun DocumentAppPreview() {
    DocumentAppTheme {
        DocumentAppFlow()
    }
}