package com.example.linarrra

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.ui.text.TextStyle
import kotlinx.coroutines.delay

// --- ТЕМА ПРИЛОЖЕНИЯ ---
@Composable
fun DocumentAppTheme(content: @Composable () -> Unit) {
    val colors = lightColorScheme(
        primary = Color(0xFFFF5722),
        onPrimary = Color.White,
        primaryContainer = Color(0xFFFFCCBC),
        onPrimaryContainer = Color(0xFF4C0F00),
        secondary = Color(0xFFE91E63),
        onSecondary = Color.White,
        tertiary = Color(0xFF00BCD4),
        onTertiary = Color.White,
        background = Color(0xFFFAFAFA),
        surface = Color.White
    )
    MaterialTheme(
        colorScheme = colors,
        typography = MaterialTheme.typography,
        content = content
    )
}

// --- ГЛАВНАЯ АКТИВНОСТЬ ---
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Обработчик ошибок для отладки
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            android.util.Log.e("APP_CRASH", "Crash in thread: ${thread.name}", throwable)
            throwable.printStackTrace()
        }

        setContent {
            DocumentAppTheme {
                DocumentAppFlow()
            }
        }
    }
}


// --- ГЛАВНЫЙ ПОТОК ---
// Добавляем новые состояния
enum class AppState {
    AUTH, FEATURES, FUNCTION_SELECTION, DOCUMENT_FILLING,
    DOCUMENT_SENDING, CHAT, MAIN_APP
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentAppFlow() {
    var appState by remember { mutableStateOf(AppState.AUTH) }
    var chatReceiverId by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = when (appState) {
                            AppState.AUTH, AppState.FEATURES -> "Электронный документооборот"
                            AppState.FUNCTION_SELECTION -> "Выбор функции"
                            AppState.DOCUMENT_FILLING -> "Заполнение документа"
                            AppState.DOCUMENT_SENDING -> "Отправка документа"
                            AppState.CHAT -> "Чат"
                            AppState.MAIN_APP -> "Рабочий стол"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    when (appState) {
                        AppState.DOCUMENT_FILLING,
                        AppState.DOCUMENT_SENDING,
                        AppState.CHAT -> {
                            IconButton(onClick = {
                                when (appState) {
                                    AppState.DOCUMENT_FILLING -> appState = AppState.FUNCTION_SELECTION
                                    AppState.DOCUMENT_SENDING -> appState = AppState.FUNCTION_SELECTION
                                    AppState.CHAT -> appState = AppState.DOCUMENT_SENDING
                                    AppState.AUTH -> TODO()
                                    AppState.FEATURES -> TODO()
                                    AppState.FUNCTION_SELECTION -> TODO()
                                    AppState.MAIN_APP -> TODO()
                                }
                            }) {
                                Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                            }
                        }
                        else -> {}
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            when (appState) {
                AppState.AUTH -> DocumentAuthContent(
                    onLoginSuccess = { appState = AppState.FEATURES }
                )
                AppState.FEATURES -> FeaturesOverviewScreen(
                    onFinishOnboarding = { appState = AppState.FUNCTION_SELECTION }
                )
                AppState.FUNCTION_SELECTION -> FunctionSelectionScreen(
                    onSelectFillDocument = { appState = AppState.DOCUMENT_FILLING },
                    onSelectSendDocument = { appState = AppState.DOCUMENT_SENDING },
                    onSelectArchive = { appState = AppState.MAIN_APP }
                )
                AppState.DOCUMENT_FILLING -> DocumentFillingScreen(
                    onBack = { appState = AppState.FUNCTION_SELECTION }
                )
                AppState.DOCUMENT_SENDING -> DocumentSendingScreen(
                    onBack = { appState = AppState.FUNCTION_SELECTION },
                    onNavigateToChat = { receiverId ->
                        chatReceiverId = receiverId
                        appState = AppState.CHAT
                    }
                )
                AppState.CHAT -> ChatScreen(
                    receiverId = chatReceiverId,
                    onBack = { appState = AppState.DOCUMENT_SENDING }
                )
                AppState.MAIN_APP -> MainDocumentScreen()
            }
        }
    }
}

// --- АУТЕНТИФИКАЦИЯ ---
enum class AuthScreen { LOGIN, REGISTRATION }

@Composable
fun DocumentAuthContent(onLoginSuccess: () -> Unit) {
    var currentScreen by remember { mutableStateOf(AuthScreen.LOGIN) }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        when (currentScreen) {
            AuthScreen.LOGIN -> LoginScreen(
                onNavigateToRegistration = { currentScreen = AuthScreen.REGISTRATION },
                onLoginSuccess = onLoginSuccess
            )
            AuthScreen.REGISTRATION -> RegistrationScreen(
                onNavigateToLogin = { currentScreen = AuthScreen.LOGIN },
                onRegistrationSuccess = { currentScreen = AuthScreen.LOGIN }
            )
        }
    }
}

// --- ЭКРАН ВХОДА ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(onNavigateToRegistration: () -> Unit, onLoginSuccess: () -> Unit) {
    var email by remember { mutableStateOf("test@mail.ru") }
    var password by remember { mutableStateOf("password") }
    var passwordVisible by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Добро пожаловать!",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
            )

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Электронная почта") },
                leadingIcon = { Icon(Icons.Filled.Email, contentDescription = "Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Пароль") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Пароль") },
                trailingIcon = {
                    val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(imageVector = image, contentDescription = "Показать/скрыть пароль")
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Button(
                onClick = {
                    if (email.isNotEmpty() && password.isNotEmpty()) {
                        onLoginSuccess()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Войти", fontSize = 18.sp)
            }

            Text(
                text = "Нет аккаунта? Зарегистрироваться",
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clickable(onClick = onNavigateToRegistration)
                    .padding(8.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

// --- ЭКРАН РЕГИСТРАЦИИ ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrationScreen(onNavigateToLogin: () -> Unit, onRegistrationSuccess: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Регистрация",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.secondary
            )

            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Имя пользователя") },
                leadingIcon = { Icon(Icons.Filled.Person, contentDescription = "Имя") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Электронная почта") },
                leadingIcon = { Icon(Icons.Filled.Email, contentDescription = "Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Пароль") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Пароль") },
                trailingIcon = {
                    val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(imageVector = image, contentDescription = "Показать/скрыть пароль")
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text("Подтвердить пароль") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Подтвердить пароль") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Button(
                onClick = {
                    if (password == confirmPassword && email.isNotEmpty()) {
                        onRegistrationSuccess()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Text("Зарегистрироваться", fontSize = 18.sp)
            }

            Text(
                text = "Уже есть аккаунт? Войти",
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier
                    .clickable(onClick = onNavigateToLogin)
                    .padding(8.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

// --- ВОЗМОЖНОСТИ ---
data class Feature(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val accentColor: Color
)

@Composable
fun FeatureCard(feature: Feature) {
    Card(
        modifier = Modifier
            .width(280.dp)
            .height(400.dp)
            .padding(16.dp),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            if (feature.title.isNotEmpty()) {
                Text(
                    text = feature.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = feature.accentColor,
                    textAlign = TextAlign.Center
                )
            }

            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(feature.accentColor.copy(alpha = 0.1f))
                    .border(2.dp, feature.accentColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = feature.icon,
                    contentDescription = feature.description,
                    tint = feature.accentColor,
                    modifier = Modifier.size(80.dp)
                )
            }

            Text(
                text = feature.description,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface
            )

            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.Gray)
                    .align(Alignment.End)
            ) {
                Icon(
                    Icons.Filled.AccountCircle,
                    contentDescription = "User Avatar Placeholder",
                    tint = Color.White,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
fun FeaturesOverviewScreen(onFinishOnboarding: () -> Unit) {
    val features = listOf(
        Feature(
            title = "С ВОЗВРАЩЕНИЕМ!",
            description = "Здесь вы можете создать или загрузить документ, а также загрузить его в облако компании.",
            icon = Icons.Filled.Description,
            accentColor = MaterialTheme.colorScheme.primary
        ),
        Feature(
            title = "",
            description = "Отправляйте документы коллегам и получайте от них письма. Вся коммуникация в одном месте.",
            icon = Icons.Filled.People,
            accentColor = MaterialTheme.colorScheme.secondary
        ),
        Feature(
            title = "",
            description = "Архивируйте документы, вы сможете скачать их в любой момент для дальнейшей работы!",
            icon = Icons.Filled.Archive,
            accentColor = MaterialTheme.colorScheme.tertiary
        )
    )

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceAround
    ) {
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(features) { feature ->
                FeatureCard(feature = feature)
            }
        }

        Button(
            onClick = onFinishOnboarding,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Начать работу", fontSize = 18.sp)
        }
    }
}

// --- ВЫБОР ФУНКЦИЙ ---
@Composable
fun FunctionSelectionScreen(
    onSelectFillDocument: () -> Unit,
    onSelectSendDocument: () -> Unit,
    onSelectArchive: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Text(
            text = "Выберите, что вы хотите сделать",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        SelectionButton(
            title = "Заполнить документ",
            description = "Создание нового документа по шаблону.",
            icon = Icons.Filled.Edit,
            iconColor = MaterialTheme.colorScheme.primary,
            onClick = onSelectFillDocument
        )

        Spacer(modifier = Modifier.height(16.dp))

        SelectionButton(
            title = "Отправить документ",
            description = "Пересылка документа на согласование или подписание.",
            icon = Icons.Filled.Send,
            iconColor = MaterialTheme.colorScheme.secondary,
            onClick = onSelectSendDocument
        )

        Spacer(modifier = Modifier.height(16.dp))

        SelectionButton(
            title = "Архив и поиск",
            description = "Просмотр и скачивание завершенных документов.",
            icon = Icons.Filled.Folder,
            iconColor = MaterialTheme.colorScheme.tertiary,
            onClick = onSelectArchive
        )
    }
}

@Composable
fun SelectionButton(title: String, description: String, icon: ImageVector, iconColor: Color, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .height(120.dp)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = iconColor,
                modifier = Modifier
                    .size(48.dp)
                    .padding(end = 16.dp)
            )
            Column {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// --- ЗАПОЛНЕНИЕ ДОКУМЕНТА ---
data class Template(
    val id: String,
    val name: String,
    val icon: ImageVector,
    val fields: List<FieldType>
)

enum class FieldType {
    TEXT, NUMBER, DATE, FULL_NAME, PASSPORT_ID
}

private val Typography.caption: TextStyle
    get() {
        TODO()
    }
val documentTemplates = listOf(
    Template(
        id = "passport",
        name = "Паспорт РФ",
        icon = Icons.Filled.Book,
        fields = listOf(FieldType.PASSPORT_ID, FieldType.FULL_NAME, FieldType.DATE)
    ),
    Template(
        id = "gph_contract",
        name = "Договор ГПХ",
        icon = Icons.Filled.Work,
        fields = listOf(FieldType.FULL_NAME, FieldType.TEXT, FieldType.NUMBER, FieldType.DATE)
    ),
    Template(
        id = "sale_contract",
        name = "Договор купли-продажи",
        icon = Icons.Filled.AccountBalance,
        fields = listOf(FieldType.FULL_NAME, FieldType.TEXT, FieldType.NUMBER, FieldType.DATE)
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentFillingScreen(onBack: () -> Unit) {
    var selectedTemplate by remember { mutableStateOf(documentTemplates.first()) }
    var isScanning by remember { mutableStateOf(false) }
    val fieldValues = remember { mutableStateMapOf<FieldType, String>() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        Text(
            text = "Заполнение документа: ${selectedTemplate.name}",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 24.dp),
            color = MaterialTheme.colorScheme.primary
        )

        // Выбор шаблона
        Text(
            "Выберите шаблон:",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
        )

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(documentTemplates) { template ->
                TemplateChip(
                    template = template,
                    isSelected = template.id == selectedTemplate.id,
                    onClick = {
                        selectedTemplate = template
                        fieldValues.clear()
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Кнопка сканирования
        OutlinedButton(
            onClick = { isScanning = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary)
        ) {
            Icon(Icons.Filled.CameraAlt, contentDescription = "Сканировать")
            Spacer(modifier = Modifier.width(8.dp))
            Text("Сканировать документ через камеру")
        }

        // Индикатор сканирования
        if (isScanning) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            Text("Сканирование и распознавание...")

            LaunchedEffect(isScanning) {
                delay(2000)
                isScanning = false
                selectedTemplate.fields.forEach { type ->
                    fieldValues[type] = getMockScannedValue(type)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Поля для заполнения
        Text(
            "Поля для заполнения:",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
        )

        selectedTemplate.fields.forEach { fieldType ->
            DocumentInputField(
                fieldType = fieldType,
                value = fieldValues[fieldType] ?: "",
                onValueChange = { newValue -> fieldValues[fieldType] = newValue }
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = { /* TODO */ },
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Сформировать и сохранить", fontSize = 18.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedButton(
            onClick = onBack,
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Отмена")
        }
    }
}

// Компонент для выбора шаблона
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TemplateChip(template: Template, isSelected: Boolean, onClick: () -> Unit) {
    AssistChip(
        onClick = onClick,
        label = { Text(template.name) },
        leadingIcon = {
            Icon(template.icon, contentDescription = template.name, modifier = Modifier.size(18.dp))
        },
        colors = AssistChipDefaults.assistChipColors(
            containerColor = if (isSelected)
                MaterialTheme.colorScheme.primary
            else
                MaterialTheme.colorScheme.surfaceVariant,
            labelColor = if (isSelected)
                MaterialTheme.colorScheme.onPrimary
            else
                MaterialTheme.colorScheme.onSurfaceVariant,
            leadingIconContentColor = if (isSelected)
                MaterialTheme.colorScheme.onPrimary
            else
                MaterialTheme.colorScheme.onSurfaceVariant
        ),
        border = if (isSelected)
            null
        else
            AssistChipDefaults.assistChipBorder(
                borderColor = MaterialTheme.colorScheme.outline,
                borderWidth = 1.dp
            )
    )
}

// Компонент поля ввода
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentInputField(fieldType: FieldType, value: String, onValueChange: (String) -> Unit) {
    val (label, icon, keyboardType) = when (fieldType) {
        FieldType.TEXT -> Triple("Текстовое поле", Icons.Filled.TextFields, KeyboardType.Text)
        FieldType.NUMBER -> Triple("Числовое значение", Icons.Filled.Numbers, KeyboardType.Number)
        FieldType.DATE -> Triple("Дата (ДД.ММ.ГГГГ)", Icons.Filled.CalendarToday, KeyboardType.Number)
        FieldType.FULL_NAME -> Triple("ФИО полностью", Icons.Filled.Person, KeyboardType.Text)
        FieldType.PASSPORT_ID -> Triple("Серия и номер паспорта", Icons.Filled.CreditCard, KeyboardType.Number)
    }

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        leadingIcon = { Icon(icon, contentDescription = label) },
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp)
    )
}

// Функция для имитации сканирования
fun getMockScannedValue(type: FieldType): String {
    return when (type) {
        FieldType.TEXT -> "Распознанный текст"
        FieldType.NUMBER -> "100000"
        FieldType.DATE -> "05.11.2025"
        FieldType.FULL_NAME -> "Иванов Иван Иванович"
        FieldType.PASSPORT_ID -> "4501 123456"
    }
}

// Модель сообщения в чате
data class ChatMessage(
    val id: String = "",
    val documentId: String = "",
    val documentName: String = "",
    val senderId: String = "",
    val senderName: String = "",
    val receiverId: String = "",
    val receiverName: String = "",
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: MessageStatus = MessageStatus.SENT
)

enum class MessageStatus {
    SENT, DELIVERED, READ
}

// Модель пользователя для чата
data class ChatUser(
    val id: String = "",
    val name: String = "",
    val email: String = "",
    val avatar: String = "",
    val isOnline: Boolean = false
)

// Модель документа для отправки
data class SendableDocument(
    val id: String = "",
    val title: String = "",
    val templateType: String = "",
    val fields: Map<String, String> = emptyMap(),
    val createdAt: Long = System.currentTimeMillis(),
    val ownerId: String = "",
    val ownerName: String = ""
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentSendingScreen(
    onBack: () -> Unit,
    onNavigateToChat: (String) -> Unit
) {
    var selectedDocument by remember { mutableStateOf<SendableDocument?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var selectedReceiver by remember { mutableStateOf<ChatUser?>(null) }
    var message by remember { mutableStateOf("") }

    val users = remember {
        listOf(
            ChatUser("1", "Иван Петров", "ivan@company.ru", "", true),
            ChatUser("2", "Мария Сидорова", "maria@company.ru", "", false),
            ChatUser("3", "Алексей Козлов", "alex@company.ru", "", true),
            ChatUser("4", "Елена Новикова", "elena@company.ru", "", true)
        )
    }

    val userDocuments = remember {
        listOf(
            SendableDocument("1", "Паспортные данные", "passport", emptyMap(), System.currentTimeMillis() - 86400000, "user1", "Вы"),
            SendableDocument("2", "Договор купли-продажи", "sale_contract", emptyMap(), System.currentTimeMillis() - 172800000, "user1", "Вы")
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()) // Добавляем прокрутку
    ) {
        // Заголовок
        Text(
            text = "Отправить документ",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // 1. Выбор документа
        Text(
            text = "Выберите документ для отправки:",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        LazyColumn(
            modifier = Modifier
                .height(150.dp)
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            items(userDocuments) { document ->
                DocumentSelectionItem(
                    document = document,
                    isSelected = selectedDocument?.id == document.id,
                    onSelect = { selectedDocument = document }
                )
            }
        }

        // 2. Поиск и выбор получателя
        Text(
            text = "Выберите получателя:",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Поиск сотрудников") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Поиск") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
            shape = RoundedCornerShape(12.dp)
        )

        LazyColumn(
            modifier = Modifier
                .height(200.dp)
                .fillMaxWidth()
                .padding(bottom = 16.dp)
        ) {
            items(users.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                        it.email.contains(searchQuery, ignoreCase = true)
            }) { user ->
                UserSelectionItem(
                    user = user,
                    isSelected = selectedReceiver?.id == user.id,
                    onSelect = { selectedReceiver = user }
                )
            }
        }

        // 3. Сообщение
        Text(
            text = "Сообщение (необязательно):",
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        OutlinedTextField(
            value = message,
            onValueChange = { message = it },
            label = { Text("Введите сообщение") },
            modifier = Modifier
                .fillMaxWidth()
                .height(100.dp)
                .padding(bottom = 24.dp), // Увеличиваем отступ
            shape = RoundedCornerShape(12.dp)
        )

        // Кнопки действий - ДОБАВЛЯЕМ ПРОКРУТКУ И ОТСТУПЫ
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp) // Отступ снизу для безопасности
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Кнопка отмены
                OutlinedButton(
                    onClick = onBack,
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp)
                ) {
                    Text("Отмена")
                }

                // Кнопка отправки
                Button(
                    onClick = {
                        if (selectedDocument != null && selectedReceiver != null) {
                            onNavigateToChat(selectedReceiver!!.id)
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .height(56.dp),
                    enabled = selectedDocument != null && selectedReceiver != null
                ) {
                    Text("Отправить")
                }
            }
        }

        // Добавляем дополнительный Spacer для гарантии, что кнопки видны
        Spacer(modifier = Modifier.height(16.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    receiverId: String,
    onBack: () -> Unit
) {
    var messageText by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf<ChatMessage>() }

    // Заглушка - получатель
    val receiver = remember {
        ChatUser("1", "Иван Петров", "ivan@company.ru", "", true)
    }

    // Заглушка - начальные сообщения
    LaunchedEffect(Unit) {
        messages.addAll(
            listOf(
                ChatMessage(
                    documentId = "1",
                    documentName = "Договор ГПХ №123",
                    senderId = "current",
                    senderName = "Вы",
                    receiverId = receiver.id,
                    receiverName = receiver.name,
                    message = "Привет! Отправляю договор на подписание",
                    timestamp = System.currentTimeMillis() - 3600000
                ),
                ChatMessage(
                    documentId = "2",
                    documentName = "Паспортные данные",
                    senderId = receiver.id,
                    senderName = receiver.name,
                    receiverId = "current",
                    receiverName = "Вы",
                    message = "Получил документы, спасибо! Проверю и подпишу",
                    timestamp = System.currentTimeMillis() - 1800000
                )
            )
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Шапка чата (ИСПРАВЛЕННАЯ)
        CenterAlignedTopAppBar(
            title = {
                Column {
                    Text(
                        text = receiver.name,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (receiver.isOnline) "В сети" else "Не в сети",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (receiver.isOnline) Color.Green else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Назад")
                }
            },
            colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer,
                titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
            )
        )

        // Список сообщений
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            reverseLayout = true
        ) {
            items(messages.reversed()) { message ->
                ChatMessageItem(
                    message = message,
                    isOwnMessage = message.senderId == "current"
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
        }

        // Поле ввода сообщения
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = messageText,
                onValueChange = { messageText = it },
                placeholder = { Text("Введите сообщение...") },
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 8.dp),
                shape = RoundedCornerShape(24.dp)
            )

            IconButton(
                onClick = {
                    if (messageText.isNotBlank()) {
                        val newMessage = ChatMessage(
                            senderId = "current",
                            senderName = "Вы",
                            receiverId = receiver.id,
                            receiverName = receiver.name,
                            message = messageText,
                            timestamp = System.currentTimeMillis()
                        )
                        messages.add(newMessage)
                        messageText = ""
                    }
                },
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary)
            ) {
                Icon(
                    Icons.Filled.Send,
                    contentDescription = "Отправить",
                    tint = Color.White
                )
            }
        }
    }
}
@Composable
fun ChatMessageItem(
    message: ChatMessage,
    isOwnMessage: Boolean
) {
    val alignment = if (isOwnMessage) Alignment.End else Alignment.Start
    val backgroundColor = if (isOwnMessage) MaterialTheme.colorScheme.primary
    else MaterialTheme.colorScheme.surfaceVariant
    val textColor = if (isOwnMessage) Color.White
    else MaterialTheme.colorScheme.onSurface

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
        horizontalAlignment = alignment
    ) {
        // Сообщение
        Card(
            modifier = Modifier
                .widthIn(max = 280.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = backgroundColor)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                // Если есть документ
                if (message.documentName.isNotEmpty()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        Icon(
                            Icons.Filled.AttachFile,
                            contentDescription = "Документ",
                            tint = textColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = message.documentName,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                    }
                }

                // Текст сообщения
                Text(
                    text = message.message,
                    color = textColor
                )
            }
        }

        // Время отправки
        Text(
            text = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
                .format(java.util.Date(message.timestamp)),
            style = MaterialTheme.typography.caption,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp, start = 12.dp, end = 12.dp)
        )
    }
}
@Composable
fun DocumentSelectionItem(
    document: SendableDocument,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(onClick = onSelect),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 2.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Filled.Description,
                contentDescription = "Документ",
                tint = if (isSelected) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = document.title,
                    fontWeight = FontWeight.Medium,
                    color = if (isSelected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Создан: ${java.text.SimpleDateFormat("dd.MM.yyyy", java.util.Locale.getDefault()).format(java.util.Date(document.createdAt))}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun UserSelectionItem(
    user: ChatUser,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable(onClick = onSelect),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 2.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Аватар пользователя
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = user.name.take(1).uppercase(),
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = user.name,
                    fontWeight = FontWeight.Medium,
                    color = if (isSelected) MaterialTheme.colorScheme.primary
                    else MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = user.email,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            // Индикатор онлайн
            if (user.isOnline) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color.Green)
                )
            }
        }
    }
}
// --- ГЛАВНЫЙ ЭКРАН ---
@Composable
fun MainDocumentScreen() {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.Info, contentDescription = "Placeholder", modifier = Modifier.size(96.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("Функция в разработке", style = MaterialTheme.typography.headlineLarge)
        Text("Этот экран будет содержать логику отправки/архива.")
    }
}

// --- ПРЕВЬЮ ---
@Preview(showBackground = true)
@Composable
fun DocumentAppPreview() {
    DocumentAppTheme {
        DocumentAppFlow()
    }
}