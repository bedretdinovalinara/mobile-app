package com.example.linarrra.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

@Composable
fun Linarrra(content: @Composable () -> Unit) {
    // Используем стандартные цвета Material Design 3
    val colors = lightColorScheme(
        primary = Color(0xFFFF5722), // Темно-бирюзовый
        onPrimary = Color.White,
        primaryContainer = Color(0xFFE91E63),
        onPrimaryContainer = Color(0xFF00201D),
        secondary = Color(0xFFFAFAFA), // Светло-зеленый
        onSecondary = Color.Black,
        background = Color.White,
        surface = Color.White
    )
    MaterialTheme(
        colorScheme = colors,
        typography = MaterialTheme.typography,
        content = content
    )
}
