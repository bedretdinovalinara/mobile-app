package com.example.linarrra

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.Brush

// --- 1. ТЕМА ПРИЛОЖЕНИЯ ---

// МИНИМАЛЬНОЕ ОПРЕДЕЛЕНИЕ ТЕМЫ, ЧТОБЫ ИЗБЕЖАТЬ ОШИБОК
@Composable
fun DocumentAppTheme(content: @Composable () -> Unit) {
    // Используем стандартные цвета Material Design 3
    val colors = lightColorScheme(
        primary = Color(0xFFFF5722), // Темно-бирюзовый (Primary)
        onPrimary = Color.White,
        primaryContainer = Color(0xFFE91E63), // Светло-бирюзовый (TopBar Background)
        onPrimaryContainer = Color(0xFF00201D), // Темный (TopBar Text)
        secondary = Color(0xFFFF5722), // Светло-зеленый (Secondary/Accent)
        onSecondary = Color.Black,
        background = Color(0xFFF0F4F3), // Слегка серый фон для контраста
        surface = Color.White
    )
    MaterialTheme(
        colorScheme = colors,
        typography = MaterialTheme.typography,
        content = content
    )
}

// --- 2. ГЛАВНАЯ АКТИВНОСТЬ ---

// Обертка для запуска приложения: НАЧАЛЬНАЯ ТОЧКА
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Устанавливаем контент Compose для всей активности
        setContent {
            // Оборачиваем наше приложение в определенную выше тему
            DocumentAppTheme {
                DocumentAppFlow() // Запускаем наш основной поток навигации
            }
        }
    }
}

// --- 3. ГЛАВНЫЙ ПОТОК (CONTAINER) ---

// Состояния, описывающие основной поток приложения
enum class AppState {
    AUTH,           // Вход / Регистрация
    FEATURES,       // Обзор возможностей (новый экран)
    MAIN_APP        // Основной рабочий экран
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DocumentAppFlow() {
    // Состояние, которое определяет текущий главный экран
    var appState by remember { mutableStateOf(AppState.AUTH) }
    // Временно для тестирования можно установить AppState.FEATURES

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Электронный документооборот",
                        fontWeight = FontWeight.Bold
                    )
                },
                // ИСПОЛЬЗУЕМ ВСТРОЕННЫЙ МЕТОД ДЛЯ ЦВЕТОВ
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            when (appState) {
                AppState.AUTH -> DocumentAuthContent(
                    onLoginSuccess = { appState = AppState.FEATURES }
                )
                AppState.FEATURES -> FeaturesOverviewScreen(
                    onFinishOnboarding = { appState = AppState.MAIN_APP }
                )
                AppState.MAIN_APP -> MainDocumentScreen()
            }
        }
    }
}


// --- 4. КОНТЕНТ АУТЕНТИФИКАЦИИ ---
// Этот Composable управляет навигацией между Входом и Регистрацией.
enum class AuthScreen {
    LOGIN,
    REGISTRATION
}

@Composable
fun DocumentAuthContent(onLoginSuccess: () -> Unit) {
    var currentScreen by remember { mutableStateOf(AuthScreen.LOGIN) }

    // Вспомогательный механизм для передачи onLoginSuccess
    val onRegistrationSuccess = {
        // После успешной регистрации переходим на экран входа
        currentScreen = AuthScreen.LOGIN
    }

    // Сохраняем исходный отступ (16dp)
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        when (currentScreen) {
            AuthScreen.LOGIN -> LoginScreen(
                onNavigateToRegistration = { currentScreen = AuthScreen.REGISTRATION },
                onLoginSuccess = onLoginSuccess
            )
            AuthScreen.REGISTRATION -> RegistrationScreen(
                onNavigateToLogin = { currentScreen = AuthScreen.LOGIN },
                onRegistrationSuccess = onRegistrationSuccess
            )
        }
    }
}


// --- 5. ЭКРАН ВХОДА (ОСТАВЛЕН БЕЗ ИЗМЕНЕНИЙ, КРОМЕ ВЫЗОВА onLoginSuccess) ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(onNavigateToRegistration: () -> Unit, onLoginSuccess: () -> Unit) {
    var email by remember { mutableStateOf("test@mail.ru") }
    var password by remember { mutableStateOf("password") }
    var passwordVisible by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 16.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Добро пожаловать!",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Поле для Email
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Электронная почта") },
                leadingIcon = { Icon(Icons.Filled.Email, contentDescription = "Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Поле для Пароля
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Пароль") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Пароль") },
                trailingIcon = {
                    val image = if (passwordVisible)
                        Icons.Filled.Visibility
                    else Icons.Filled.VisibilityOff

                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(imageVector = image, contentDescription = "Показать/скрыть пароль")
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Кнопка Входа
            Button(
                onClick = {
                    // TODO: Здесь будет логика проверки учетных данных
                    if (email.isNotEmpty() && password.isNotEmpty()) {
                        onLoginSuccess() // <-- Вызов перехода к новому экрану
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Войти", fontSize = 18.sp)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Ссылка на Регистрацию
            Text(
                text = "Нет аккаунта? Зарегистрироваться",
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .clickable(onClick = onNavigateToRegistration)
                    .padding(8.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}

// --- 6. ЭКРАН РЕГИСТРАЦИИ (ОСТАВЛЕН БЕЗ ИЗМЕНЕНИЙ) ---

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegistrationScreen(onNavigateToLogin: () -> Unit, onRegistrationSuccess: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Регистрация",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.secondary
            )
            Spacer(modifier = Modifier.height(8.dp))

            // Поле для Имени
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Имя пользователя") },
                leadingIcon = { Icon(Icons.Filled.Person, contentDescription = "Имя") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Поле для Email
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Электронная почта") },
                leadingIcon = { Icon(Icons.Filled.Email, contentDescription = "Email") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Поле для Пароля
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Пароль") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Пароль") },
                trailingIcon = {
                    val image = if (passwordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff
                    IconButton(onClick = { passwordVisible = !passwordVisible }) {
                        Icon(imageVector = image, contentDescription = "Показать/скрыть пароль")
                    }
                },
                visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Поле для Подтверждения Пароля
            OutlinedTextField(
                value = confirmPassword,
                onValueChange = { confirmPassword = it },
                label = { Text("Подтвердить пароль") },
                leadingIcon = { Icon(Icons.Filled.Lock, contentDescription = "Подтвердить пароль") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Кнопка Регистрации
            Button(
                onClick = {
                    // TODO: Здесь будет логика проверки и регистрации пользователя
                    if (password == confirmPassword && email.isNotEmpty()) {
                        onRegistrationSuccess()
                    } else if (password != confirmPassword) {
                        // В реальном приложении: показать ошибку пользователю
                        println("Пароли не совпадают")
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Text("Зарегистрироваться", fontSize = 18.sp)
            }

            // Ссылка на Вход
            Text(
                text = "Уже есть аккаунт? Войти",
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier
                    .clickable(onClick = onNavigateToLogin)
                    .padding(8.dp),
                style = MaterialTheme.typography.bodyLarge
            )
        }
    }
}


// --- 7. КОМПОНЕНТ КАРТОЧКИ ВОЗМОЖНОСТЕЙ ---

data class Feature(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val color: Color
)

@Composable
fun FeatureCard(feature: Feature) {
    Card(
        modifier = Modifier
            .width(280.dp) // Фиксированная ширина для карусели
            .height(400.dp)
            .padding(16.dp),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Заголовок (например, "С Возвращением!") - Временно используем для первого экрана
            if (feature.title.isNotEmpty()) {
                Text(
                    text = feature.title,
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = feature.color,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
            } else {
                Spacer(modifier = Modifier.height(10.dp))
            }


            // Иконка/Иллюстрация
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(feature.color.copy(alpha = 0.1f))
                    .border(2.dp, feature.color, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = feature.icon,
                    contentDescription = feature.description,
                    tint = feature.color,
                    modifier = Modifier.size(80.dp)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Описание функции
            Text(
                text = feature.description,
                style = MaterialTheme.typography.bodyLarge,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurface
            )

            // Заглушка для аватара пользователя (как в макете)
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color.Gray)
                    .align(Alignment.End)
            ) {
                Icon(
                    Icons.Filled.AccountCircle,
                    contentDescription = "User Avatar Placeholder",
                    tint = Color.White,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}


// --- 8. ЭКРАН ОБЗОРА ВОЗМОЖНОСТЕЙ (ОНБОРДИНГ) ---

@Composable
fun FeaturesOverviewScreen(onFinishOnboarding: () -> Unit) {
    val features = listOf(
        Feature(
            title = "С ВОЗВРАЩЕНИЕМ!",
            description = "Здесь вы можете создать или загрузить документ, а также загрузить его в облако компании.",
            icon = Icons.Filled.Description,
            color = MaterialTheme.colorScheme.primary
        ),
        Feature(
            title = "",
            description = "Отправляйте документы коллегам и получайте от них письма. Вся коммуникация в одном месте.",
            icon = Icons.Filled.People,
            color = MaterialTheme.colorScheme.secondary
        ),
        Feature(
            title = "",
            description = "Архивируйте документы, вы сможете скачать их в любой момент для дальнейшей работы!",
            icon = Icons.Filled.Archive,
            color = MaterialTheme.colorScheme.tertiary // Используем другой цвет для разнообразия
        )
    )

    // Используем LazyRow для имитации горизонтальной прокрутки (как в макете)
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceAround
    ) {

        // Карусель карточек (имитация Pager'а с прокруткой)
        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(features) { feature ->
                FeatureCard(feature = feature)
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Кнопка для перехода к главному приложению
        Button(
            onClick = onFinishOnboarding,
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(56.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text("Начать работу", fontSize = 18.sp)
        }
    }
}


// --- 9. ГЛАВНЫЙ РАБОЧИЙ ЭКРАН (ЗАГЛУШКА) ---

@Composable
fun MainDocumentScreen() {
    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Filled.CheckCircle,
            contentDescription = "Success",
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(96.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Основное приложение ЭДО",
            style = MaterialTheme.typography.headlineLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Успешный вход! Здесь будет ваш рабочий стол.",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

// --- 10. ПРЕВЬЮ ---

// Пример превью, чтобы увидеть, как выглядит приложение
@Preview(showBackground = true)
@Composable
fun DocumentAppPreview() {
    // Используем определенную выше тему
    DocumentAppTheme {
        DocumentAppFlow()
    }
}
